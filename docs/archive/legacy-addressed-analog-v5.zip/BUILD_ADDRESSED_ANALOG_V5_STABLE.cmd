@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_ADDRESSED_ANALOG_V5_STABLE.ps1"
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
  echo.
  echo Build failed with exit code %EXITCODE%.
  pause
  exit /b %EXITCODE%
)
echo.
echo Build complete. See SEND_ADDRESSED_ANALOG_V5_STABLE_EXE.
pause
