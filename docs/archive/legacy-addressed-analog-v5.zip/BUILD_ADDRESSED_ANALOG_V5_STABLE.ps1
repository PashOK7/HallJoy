[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$root = Split-Path -Parent $PSCommandPath
$pluginRoot = Join-Path $root 'UniversalAnalogPluginFixed'
$hallJoyRoot = Join-Path $root 'HallJoyProject'
$pluginBuild = Join-Path $pluginRoot 'tools\build_fixed_plugin.ps1'
$project = Join-Path $hallJoyRoot 'HallJoy\HallJoy.vcxproj'
$runtime = Join-Path $hallJoyRoot 'runtime'
$outDir = Join-Path $hallJoyRoot 'x64\AddressedAnalogV5Stable'
$intDir = Join-Path $outDir 'obj'
$targetName = 'HallJoy_AddressedAnalog_v5_Stable'
$exe = Join-Path $outDir ($targetName + '.exe')
$pdb = Join-Path $outDir ($targetName + '.pdb')
$sendDir = Join-Path $root 'SEND_ADDRESSED_ANALOG_V5_STABLE_EXE'
$vigemLib = Join-Path $hallJoyRoot 'third_party\ViGEmClient\lib\release\x64\ViGEmClient.lib'
$vigemExpectedSha256 = '800239E478698154F544AD81C4580A3E6A2A48358D1FF67D970C996B382640B4'

$required = @(
    $pluginBuild,
    $project,
    (Join-Path $hallJoyRoot 'HallJoy\addressed_analog_backend.cpp'),
    (Join-Path $hallJoyRoot 'HallJoy\addressed_poll_scheduler.cpp'),
    $vigemLib
)
$missing = @($required | Where-Object { -not (Test-Path -LiteralPath $_) })
if ($missing.Count -ne 0) {
    $missing | ForEach-Object { Write-Host "Missing: $_" -ForegroundColor Red }
    throw 'Source package is incomplete.'
}

$vigemInfo = Get-Item -LiteralPath $vigemLib
$vigemHash = (Get-FileHash -LiteralPath $vigemLib -Algorithm SHA256).Hash
if ($vigemInfo.Length -ne 1245970 -or $vigemHash -ne $vigemExpectedSha256) {
    throw "ViGEmClient.lib preflight failed. Size=$($vigemInfo.Length), SHA-256=$vigemHash"
}

Write-Host 'Building embedded analogue plugin...' -ForegroundColor Cyan
& powershell -NoProfile -ExecutionPolicy Bypass -File $pluginBuild
if ($LASTEXITCODE -ne 0) { throw "Plugin build failed: $LASTEXITCODE" }

$pluginOut = Join-Path $pluginRoot 'dist\universal-analog-plugin'
New-Item -ItemType Directory -Path $runtime -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $pluginOut 'abiv0.dll') -Destination (Join-Path $runtime 'universal_analog_abiv0.dll') -Force
Copy-Item -LiteralPath (Join-Path $pluginOut 'abiv1.dll') -Destination (Join-Path $runtime 'universal_analog_abiv1.dll') -Force

$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$msbuild = $null
if (Test-Path -LiteralPath $vswhere) {
    $msbuild = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -find 'MSBuild\**\Bin\amd64\MSBuild.exe' | Select-Object -First 1
}
if (-not $msbuild) {
    $candidates = @(
        'C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\amd64\MSBuild.exe',
        'C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\amd64\MSBuild.exe',
        'C:\Program Files\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\amd64\MSBuild.exe',
        'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\amd64\MSBuild.exe'
    )
    $msbuild = $candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
}
if (-not $msbuild) {
    throw 'MSBuild x64 was not found. Install Visual Studio 2022 with Desktop development with C++.'
}

New-Item -ItemType Directory -Path $outDir -Force | Out-Null
Write-Host "Building $targetName.exe..." -ForegroundColor Cyan
& $msbuild $project `
    '/t:Rebuild' `
    '/p:Configuration=Release' `
    '/p:Platform=x64' `
    "/p:TargetName=$targetName" `
    "/p:OutDir=$outDir\" `
    "/p:IntDir=$intDir\" `
    '/m'
if ($LASTEXITCODE -ne 0) { throw "HallJoy build failed: $LASTEXITCODE" }
if (-not (Test-Path -LiteralPath $exe)) { throw "Executable not produced: $exe" }

if (Test-Path -LiteralPath $sendDir) { Remove-Item -LiteralPath $sendDir -Recurse -Force }
New-Item -ItemType Directory -Path $sendDir -Force | Out-Null
Copy-Item -LiteralPath $exe -Destination $sendDir -Force

$symbols = Join-Path $outDir 'LOCAL_SYMBOLS_DO_NOT_SEND'
New-Item -ItemType Directory -Path $symbols -Force | Out-Null
if (Test-Path -LiteralPath $pdb) { Copy-Item -LiteralPath $pdb -Destination $symbols -Force }

@'
Run HallJoy_AddressedAnalog_v5_Stable.exe normally.
Close vendor keyboard configurators while testing.

HallJoyAddressedAnalog.log records candidate/probe/session events and one compact aggregate line every ten seconds.
HallJoyAddressedAnalogTrace.log is created only after an anomaly and contains a bounded ring of recent transactions.
If analogue input stops, return both files without restarting HallJoy first when possible.
'@ | Set-Content -LiteralPath (Join-Path $sendDir 'README_FOR_TEST.txt') -Encoding UTF8

Write-Host ''
Write-Host 'Build completed:' -ForegroundColor Green
Write-Host "  $(Join-Path $sendDir ($targetName + '.exe'))" -ForegroundColor Green
