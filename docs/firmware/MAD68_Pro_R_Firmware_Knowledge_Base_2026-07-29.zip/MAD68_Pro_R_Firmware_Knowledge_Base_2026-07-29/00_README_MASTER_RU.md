# MADLIONS MAD 68 Pro R — полная база знаний по прошивке и Hall-протоколу

Дата сборки пакета: **29 июля 2026 года**  
Целевой образ: **SHA-256 `2a7df4ffc491476b79da5333f51179f68fbbb5c5e146e987cfb5df764b79cead`**  
Размер образа: **124656 bytes (`0x1E6F0`)**

Этот архив объединяет актуальную документацию, машинные таблицы, полный дизассемблированный образ, raw evidence, проверочные скрипты, аппаратный журнал и исторические материалы реверса.

## 1. Главный итог

Для указанного точного firmware SHA найден и аппаратно подтверждён скрытый live Hall transport:

```text
Hall scan
  -> live Hall RAM
  -> async builder 0x9F30
  -> service 0xA0A8
  -> vendor HID interface 1
  -> EP82 IN
  -> 64-byte report с header A0
```

Основное аналоговое значение клавиши:

```text
raw = BE16(packet[4], packet[5])
normalized = clamp(raw, 0, 1600) / 1600.0
```

Это значение реально изменялось на устройстве:

```text
W: 0 -> 1600 -> 0
A: 5 -> 1565 -> 0
```

Значение не следует называть миллиметрами. Доказан внутренний диапазон firmware `0..1600`, но физическая единица не восстановлена.

## 2. Точная идентификация образа

- Image base: `0x00005000`.
- Формула: `VA = file_offset + 0x5000`.
- ISA: little-endian RV32, compressed instructions, floating point, WCH/QingKe XWCHC.
- `gp = 0x200032A0`.
- `sp = 0x20008000`.
- USB VID/PID: `373B:1109`.
- bcdDevice: `0x0102`.

Архив не утверждает совместимость активирующих команд с другими firmware SHA или bcdDevice. Для неизвестной ревизии безопасно только пассивное чтение.

## 3. USB topology

Прошивка объявляет три интерфейса:

1. IF0 — boot keyboard, EP81 IN, 8-byte payload.
2. IF1 — vendor HID, EP82 IN / EP04 OUT, 64-byte IN и OUT payload.
3. IF2 — composite HID, EP83 IN: NKRO/keyboard, mouse, consumer и system reports.

Vendor HID descriptor не содержит Feature report. EP0 реализует стандартные USB и HID class requests; отдельного vendor-control API для чтения Hall не найдено.

Windows показывает IF1 как 65-byte reports, потому что API добавляет report-ID byte перед 64-byte payload.

## 4. Vendor protocol framing

Обычный request:

```text
byte 0    = 0x55
byte 1    = opcode
bytes 2.. = length/payload/checksum according to parser
```

Обычный успешный response начинается с `0xAA`. Checksum error использует `0xAB`. Неизвестная команда попадает в default handler.

Header `0x5F` обходит часть обычного framing/checksum, но использует ту же jump table. Второго скрытого dispatcher не найдено.

Прошивка имеет один software RX buffer и один pending flag, без очереди команд. Поэтому команды необходимо сериализовать и ждать соответствующий ACK.

## 5. Полный command dispatcher

Jump table содержит 243 entry для opcode `0x00..0xF2`. Активны 30 opcode. Полная карта находится в:

```text
03_TABLES/command_map_final.csv
03_TABLES/mad68pr_command_map_audited.csv
```

Критически важные классы:

- Read-only: `03,04,05,07,08,0A,0C,A0,A2,A4,A6,B0,DE,F1`.
- Volatile state: `01,02,A8,A9`.
- RAM write: `DD`.
- Flash/data-flash write: `06,09,0B,0D,A1,A3,A5,A7,B1,F2`.
- Factory/destructive: `EE`.

**Не использовать opcode `0x0B` как диагностический probe.** Он ведёт к flash/data-flash erase/program path, а не к безопасному RAM framebuffer.

Для HallJoy runtime allow-list должен содержать только `A8` и `A9`.

## 6. Раздельные состояния A8 и A9

Главная исправленная машина состояний:

| Назначение | RAM | A8 | A9 |
|---|---:|---:|---:|
| service/input suppression | `0x20002B40` (`gp-0x760`) | `1` | `0` |
| forced sweep counter | `0x20002B3F` (`gp-0x761`) | `3` | не очищает |
| telemetry gate | `0x2000580B`, bit `0x08` | устанавливает | не меняет |
| auxiliary 72-byte array | `0x20004BE4` | заполняет `FF` | очищает `00` |

Следствие:

```text
A8 включает telemetry и временно меняет/подавляет normal digital path.
A9 восстанавливает normal digital service state.
A9 не выключает telemetry gate.
```

Поэтому подтверждённая последовательность:

```text
пассивно слушать A0
-> A9, дождаться AA/A9
-> дождаться all-keys-up
-> A8, дождаться AA/A8
-> A9, дождаться AA/A9
-> принимать и валидировать A0
```

`A8` переинициализирует baseline из текущих Hall samples. Если клавиша удерживается во время `A8`, её нажатое положение может стать новой baseline. Поэтому all-keys-up перед `A8` обязателен.

Нельзя статически обещать ноль потерянных digital events в коротком окне между выполнением `A8` и обработкой финального `A9`.

## 7. Async Hall packet A0

Builder: `0x9F30`.  
Service/scheduler: `0xA0A8`.  
Endpoint: IF1 / EP82 IN.  
Descriptor table: `0xFB74`.

Полезная структура:

| Bytes | Значение |
|---|---|
| 0 | `0xA0`, async Hall header |
| 1..3 | физический descriptor клавиши |
| 4..5 | **primary live analog**, BE16, `0..1600` |
| 6 | high byte secondary/gate value |
| 7 | условный state/threshold helper byte |
| 8 | auxiliary low byte |
| 9 | auxiliary byte |
| 10 | per-key state |
| 11..13 | decimal serialization adaptive calibration scale; не основной аналог |
| 14..15 | selected threshold, BE16 |
| 16..17 | auxiliary live word, BE16 |
| 18..19 | baseline/reference, BE16 |
| 20..63 | builder не записывает; stale/undefined, игнорировать |

Точная таблица: `03_TABLES/a0_packet_format_final.csv`.

## 8. Hall RAM dataflow

Основные массивы:

- `0x20003CFC`: 72 × u16 raw Hall/ADC-like samples.
- `0x20003EAC`: 72 × u16 baseline/reference.
- `0x20003F3C`: filter accumulators.
- `0x200040EC`: 72 records по 8 bytes, включая float calibration scale/state.
- `0x200043BC`: auxiliary live word.
- `0x2000444C`: **72 × u16 primary live analog `0..1600`**.
- `0x2000456C`: telemetry mirror.
- `0x20004644`: change source/secondary state magnitude.
- `0x20004764`: secondary/gate value.
- `0x20004A7C`, `0x20004B9C`: auxiliary fields.
- `0x20004BE4`: 72-byte service/diagnostic array.
- `0x20004D4C`: per-key Hall config records.
- `0x2000514C`: runtime buffer readable через `DE`.
- `0x200052CC`: runtime buffer writable через `DD`.
- `0x2000580B`: config/mode byte, telemetry gate bit 3.

Формула primary analog восстановлена как нормализованная величина на основе абсолютного отклонения filtered Hall sample от baseline, делённого на per-key calibration scale, с ограничением до `1600`.

Подробности: `03_TABLES/hall_ram_dataflow_final.csv` и `04_DISASSEMBLY_AND_EVIDENCE/hall_scan_primary_analog.txt`.

## 9. Клавиши и scanner slots

Прошивка сканирует 72 slot. Четыре gap:

```text
8, 16, 35, 59
```

Физических descriptors: `68`, все уникальны. Полная карта scanner slot -> descriptor -> key находится в `03_TABLES/key_descriptor_map_final.csv`.

Особенность Fn:

- telemetry descriptor существует;
- стандартного USB HID keyboard usage для Fn нет;
- Fn можно учитывать для контроля целостности snapshot `68/68`, но нельзя публиковать как выдуманную стандартную клавишу.

Scanner slots WASD:

```text
A = 9
D = 10
S = 55
W = 64
```

## 10. Scheduler и ограничение пропускной способности

Service проверяет telemetry gate и limiter примерно в 15 firmware ticks.

После `A8`:

- counter устанавливается в `3`;
- выполняются forced sweeps по 72 slot;
- gaps не формируют пакеты, поэтому каждый полный проход содержит 68 `A0`.

После forced sweeps scheduler переходит к change-driven ветке:

- сравнивает source и mirror;
- ищет первый изменившийся slot;
- формирует только один пакет за разрешённый service interval;
- следующий поиск снова начинается с низкого slot.

Следствие: aggregate throughput около `66.7 packets/s` при 1 ms tick. Несколько одновременно движущихся клавиш делят эту пропускную способность; низкие scanner slots могут временно задерживать высокие.

Это ограничение stock firmware. Host-side код может безопасно обнаруживать starvation и делать per-key fallback, но не может увеличить firmware throughput без нового протокола или модификации прошивки.

## 11. Уникальность live Hall transport

Для точного SHA проверены:

- все 243 opcode;
- EP0 standard/HID paths;
- отсутствие vendor EP0 API;
- standard boot/composite HID descriptors;
- все interrupt-IN sender call-sites;
- прямые USB endpoint/DMA register accesses;
- interrupt handlers;
- indirect/literal function pointers;
- все ссылки на async vendor buffer.

Альтернативного host-visible live Hall producer не найдено. Итог:

```text
Единственный обнаруженный stock live Hall transport — async A0 на IF1/EP82.
```

Host opcode `0xA0` — отдельная read/config command. Его response нельзя смешивать с async Hall packet marker `0xA0`. HallJoy не должен отправлять host opcode `A0` для live stream.

## 12. Аппаратное подтверждение

Реальный журнал подтверждает:

- валидные ACK `A9/A8/A9`;
- четыре последовательных цикла по 68 descriptors после финального `A9`;
- 272 `A0` после TX финального `A9`, 271 после его ACK;
- median packet interval `15 ms`;
- `W=1600`, `A=1565`;
- отсутствие checksum/malformed errors;
- normal shutdown процесса.

Поток после финального `A9` не может объясняться только очередью: за 7–10 ms между ACK `A8` и финальным `A9` прошивка не могла заранее сформировать сотни пакетов при limiter около 15 ms.

Подробная сводка: `06_HARDWARE_EVIDENCE/HARDWARE_LOG_SUMMARY_RU.md`.

## 13. Что остаётся недоказанным

1. Специальный аппаратный post-sweep тест: физическое нажатие, начатое через 5+ секунд после стартовых циклов.
2. Реальная latency и jitter для каждой WASD в steady-state.
3. Fairness при одновременном движении A/D/S/W.
4. Плавность stock scheduler для ViGEm sticks/triggers под многоклавишной нагрузкой.
5. Физическая единица `raw/1600`; это нормализованная firmware coordinate, не доказанные миллиметры.
6. Совместимость активного arm sequence с другими firmware SHA/revisions.
7. Полное отсутствие единственного потерянного digital event во время короткого A8->A9 transition.

## 14. Рекомендации для HallJoy

Минимально безопасная интеграция:

1. Сохранить UAP/Wooting и остальные native backends.
2. Исключить только `VID 373B / PID 1109` из UAP до открытия vendor HID path, чтобы не было конкуренции за EP82.
3. Пассивно слушать уже активный `A0`.
4. Активировать команды только на `bcdDevice 0x0102` или точном allow-list firmware.
5. Перед `A8` дождаться all-keys-up.
6. Строго сериализовать `A9 -> A8 -> A9` с проверкой каждого `AA/opcode`.
7. Не считать ACK доказательством Hall stream.
8. Не считать startup `68/68` доказательством post-sweep steady-state.
9. Коррелировать физические Raw Input edges с более новым per-key `A0` generation/sequence.
10. При starvation делать per-key fallback, а не повторять `A8` из-за одной клавиши.
11. При исчезновении всего A0 transport использовать ограниченный recovery.
12. На normal/crash shutdown выполнять best-effort `A9`.
13. Игнорировать `A0[20..63]`.
14. Использовать только `BE16(A0[4..5])/1600` как основной analog source.
15. Передавать данные через штатный HallJoy path: raw cache -> curves/deadzones -> blue progress bar -> remap -> ViGEm.

## 15. Уровни уверенности

### Доказано статически и/или аппаратно

- точный image base и SHA;
- USB topology;
- command dispatcher;
- A8/A9 state split;
- telemetry gate сохраняется после A9;
- async A0 producer и endpoint;
- key descriptors 68/68;
- primary analog в bytes 4..5;
- диапазон 0..1600;
- A0 после финального A9;
- полный ordered snapshot;
- отсутствие второго найденного host-visible Hall transport.

### Высокая уверенность, требует дополнительного измерения качества

- пригодность steady branch для плавного одиночного WASD;
- практическая latency under contention;
- достаточность stock throughput для сложных ViGEm mappings.

### Не доказано

- физические миллиметры;
- поддержка неизвестных firmware revisions;
- идеальная fairness scheduler;
- нулевая потеря digital events во всех аварийных сценариях.

## 16. Как читать архив

1. Начать с этого файла.
2. Прочитать `02_CURRENT_DOCUMENTATION/MAD68_PRO_R_FIRMWARE_FINAL_AUDIT_RU.md`.
3. Затем `02_CURRENT_DOCUMENTATION/MAD68PRO_R_NATIVE_V3_4_CRITIQUE_RESOLUTION_RU.md` — там raw instructions A8/A9 и разбор критики.
4. Использовать CSV/JSON из `03_TABLES` как машиночитаемый источник.
5. Проверять выводы по `04_DISASSEMBLY_AND_EVIDENCE`.
6. Воспроизводить assertions скриптами из `05_REPRODUCIBILITY`.
7. Сопоставлять с реальным устройством через `06_HARDWARE_EVIDENCE`.
8. `07_CRITIQUE_AND_HISTORY` читать только вместе с предупреждением о позднейших исправлениях.

## 17. Правовой и эксплуатационный предел

Пакет предназначен для анализа совместимости и разработки host-side поддержки собственного устройства. В нём присутствует исходный бинарный образ, предоставленный пользователем, и дизассемблированные материалы. Любые write/factory opcode могут повредить конфигурацию или прошивку; архив не рекомендует их выполнять.
