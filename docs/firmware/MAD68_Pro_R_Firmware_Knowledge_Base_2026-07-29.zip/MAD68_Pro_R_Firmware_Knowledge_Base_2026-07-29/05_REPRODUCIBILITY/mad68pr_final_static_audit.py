#!/usr/bin/env python3
"""Final reproducible static audit for MADLIONS MAD 68 Pro R.

No hardware access. Validates the exact firmware SHA, USB/control/data paths,
full vendor dispatch, hidden Hall telemetry, and the actual analog field.
"""
from __future__ import annotations
import csv, hashlib, json, re, struct, sys
from pathlib import Path
from collections import defaultdict

BASE=0x5000
SIZE=124656
SHA="2a7df4ffc491476b79da5333f51179f68fbbb5c5e146e987cfb5df764b79cead"
JUMP_VA=0xF2C0
DEFAULT=0x66BE
ACTIVE={
0x01:(0x66B6,"runtime_flag_set","volatile"),0x02:(0x66B0,"runtime_flag_clear","volatile"),
0x03:(0x6642,"version_read","read_only"),0x04:(0x6616,"nvm_read_235F0","read_only"),
0x05:(0x65EA,"nvm_read_20100","read_only"),0x06:(0x65E4,"nvm_write_20100","flash_write"),
0x07:(0x65AE,"immutable_read_108A8","read_only"),0x08:(0x6576,"nvm_read_225F0","read_only"),
0x09:(0x6570,"nvm_write_225F0","flash_write"),0x0A:(0x6538,"nvm_read_20200","read_only"),
0x0B:(0x6532,"nvm_write_20200","flash_write"),0x0C:(0x64FA,"nvm_read_215F0","read_only"),
0x0D:(0x64F6,"nvm_write_215F0","flash_write"),0xA0:(0x64BE,"nvm_read_20400","read_only"),
0xA1:(0x64BA,"nvm_write_20400","flash_write"),0xA2:(0x6482,"nvm_read_20800","read_only"),
0xA3:(0x647E,"nvm_write_20800","flash_write"),0xA4:(0x6446,"nvm_read_20BF0","read_only"),
0xA5:(0x6442,"nvm_write_20BF0","flash_write"),0xA6:(0x640A,"nvm_read_20CF0","read_only"),
0xA7:(0x6406,"nvm_write_20CF0","flash_write"),0xA8:(0x63F8,"hall_telemetry_arm","volatile_state"),
0xA9:(0x63E0,"hall_input_suppression_clear","volatile_state"),0xB0:(0x63A8,"nvm_read_20000","read_only"),
0xB1:(0x63A4,"nvm_write_20000","flash_write"),0xDD:(0x63A0,"ram_write_200052CC","ram_write"),
0xDE:(0x639C,"ram_read_2000514C","read_only"),0xEE:(0x6394,"factory_maintenance_arm","destructive"),
0xF1:(0x635C,"nvm_read_21DF0","read_only"),0xF2:(0x62F0,"nvm_write_21DF0","flash_write")}
STD_TABLE=[0x595A,0x5A08,0x57EC,0x59D6,0x57EC,0x59CA,0x59B0,0x57EC,0x599E,0x598C,0x597C,0x56CE]
DESC_TABLE=[0x5B44,0x5B2A,0x5B06,0x5AD0,0x5B44,0x5B44,0x5AB6,0x5B44,0x5B44]
CLASS_TABLE=[0x57EC,0x57EC,0x5BA4,0x5BB6,0x57EC,0x57EC,0x57EC,0x57EC,0x57EC,0x56CE,0x5B92,0x5B7C]
EXPECTED_CALLS={
0x545A:[0x7A10,0x7A50,0x7A78,0x7A98,0x7AB0,0x7ACC,0x7AE4],
0x9F30:[0xA126,0xA13A],0xA0A8:[0x86EC],0xA15A:[0x5340,0xDEEE,0xE418],0xA1A4:[0x6048,0x85CE,0xE41E]}
VECTOR_EXPECTED={0x7C:0x66EA,0xA4:0xDEF8,0xE8:0xB01A,0xEC:0x7AF4,0x18C:0x558E}
USB_ROOT_RANGES=[(0x5376,0x53F0,"endpoint_dma_init"),(0x53F4,0x545A,"usb_attach_init"),
 (0x545A,0x558E,"interrupt_in_sender"),(0x558E,0x5E62,"usb_irq_ep0_ep4"),
 (0x5E62,0x5E92,"usb_reset_pullup"),(0x7350,0x7468,"endpoint_watchdog")]
USAGE={0x04:'A',0x05:'B',0x06:'C',0x07:'D',0x08:'E',0x09:'F',0x0A:'G',0x0B:'H',0x0C:'I',0x0D:'J',0x0E:'K',0x0F:'L',0x10:'M',0x11:'N',0x12:'O',0x13:'P',0x14:'Q',0x15:'R',0x16:'S',0x17:'T',0x18:'U',0x19:'V',0x1A:'W',0x1B:'X',0x1C:'Y',0x1D:'Z',0x1E:'1',0x1F:'2',0x20:'3',0x21:'4',0x22:'5',0x23:'6',0x24:'7',0x25:'8',0x26:'9',0x27:'0',0x28:'Enter',0x29:'Esc',0x2A:'Backspace',0x2B:'Tab',0x2C:'Space',0x2D:'-',0x2E:'=',0x2F:'[',0x30:']',0x31:'Backslash',0x33:'Semicolon',0x34:'Apostrophe',0x36:'Comma',0x37:'Period',0x38:'Slash',0x39:'CapsLock',0x49:'Insert',0x4B:'PageUp',0x4C:'Delete',0x4E:'PageDown',0x4F:'Right',0x50:'Left',0x51:'Down',0x52:'Up',0x87:'International1'}
MOD={1:'LeftCtrl',2:'LeftShift',4:'LeftAlt',8:'LeftGUI',16:'RightCtrl',32:'RightShift',64:'RightAlt',128:'RightGUI'}

def rd(blob,va,n):
 o=va-BASE; x=blob[o:o+n]
 assert len(x)==n,(hex(va),n,len(x)); return x

def u32s(blob,va,n): return list(struct.unpack('<'+'I'*n,rd(blob,va,4*n)))
def u16s(blob,va,n): return list(struct.unpack('<'+'H'*n,rd(blob,va,2*n)))
def csvw(path,heads,rows):
 with path.open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(heads);w.writerows(rows)
def parse_dis(path):
 line_re=re.compile(r'^\s*([0-9a-f]+):\s+([0-9a-f]+)\s+([^\s]+)(?:\s+(.*?))?\s*$')
 ins=[];calls=defaultdict(list)
 for line in path.read_text(errors='replace').splitlines():
  m=line_re.match(line)
  if not m: continue
  x={'addr':int(m.group(1),16),'raw':m.group(2),'mnem':m.group(3),'ops':(m.group(4) or '').split('<')[0].strip(),'line':line}
  ins.append(x)
  if x['mnem']=='jal':
   ms=re.findall(r'0x([0-9a-f]+)',x['ops'])
   if ms:calls[int(ms[-1],16)].append(x['addr'])
 return ins,calls

def keyname(d):
 if d==b'\0\0\0':return ''
 if d[0]==0xF0:return 'Fn' if d[1]==0xFF else 'Special_'+d.hex()
 if d[0]==0x10:
  if d[2]:return USAGE.get(d[2],f'Usage_{d[2]:02X}')
  if d[1]:return MOD.get(d[1],f'Modifier_{d[1]:02X}')
 return 'Descriptor_'+d.hex()

def require_lines(ins, checks):
 by={x['addr']:x for x in ins}
 for addr,parts in checks:
  assert addr in by,hex(addr)
  line=by[addr]['line']
  for p in parts: assert p in line,(hex(addr),p,line)

def main():
 if len(sys.argv)<4:
  print('usage: mad68pr_final_static_audit.py firmware.bin disasm.txt outdir',file=sys.stderr);return 2
 fw,dis,out=Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
 blob=fw.read_bytes(); sha=hashlib.sha256(blob).hexdigest()
 assert len(blob)==SIZE and sha==SHA,(len(blob),sha)
 ins,calls=parse_dis(dis)
 # Relevant audited routines must be completely decoded with WCH extension.
 intervals=[(0x530E,0x5346),(0x5376,0x5E62),(0x6226,0x66D8),(0x79BA,0x7AF4),(0x8500,0x8720),(0x9F30,0xA15A),(0xA2A2,0xB532)]
 unknown=[]
 for x in ins:
  if any(a<=x['addr']<b for a,b in intervals) and ('<unknown>' in x['line'] or x['mnem']=='unimp'): unknown.append(x['addr'])
 assert not unknown,[hex(x) for x in unknown[:20]]
 # Image/USB descriptors.
 dev=rd(blob,0xF8D4,18); assert dev[:2]==b'\x12\x01'
 vid,pid,bcd=struct.unpack_from('<HHH',dev,8); assert (vid,pid,bcd)==(0x373B,0x1109,0x0102)
 cfg=rd(blob,0x1161C,0x5B); assert cfg[:5]==b'\x09\x02\x5b\x00\x03'
 vrep=rd(blob,0xF874,32); assert vrep.count(b'\x95\x40\x75\x08')>=2 and b'\xb1' not in vrep
 # Full vendor dispatch.
 jump=u32s(blob,JUMP_VA,0xF3)
 for op,(handler,_,_) in ACTIVE.items(): assert jump[op]==handler,(hex(op),hex(jump[op]),hex(handler))
 assert [i for i,v in enumerate(jump) if v!=DEFAULT]==sorted(ACTIVE)
 assert len(set(jump))==31
 # EP0 standard / descriptor / HID class dispatch. Vendor type has no table/handler branch.
 assert u32s(blob,0xF1D4,len(STD_TABLE))==STD_TABLE
 assert u32s(blob,0xF204,len(DESC_TABLE))==DESC_TABLE
 assert u32s(blob,0xF290,len(CLASS_TABLE))==CLASS_TABLE
 # Interrupt roots.
 for off,va in VECTOR_EXPECTED.items(): assert struct.unpack_from('<I',blob,off)[0]==va
 # Exact producer calls and async buffer refs.
 for target,srcs in EXPECTED_CALLS.items(): assert calls.get(target,[])==srcs,(hex(target),calls.get(target),srcs)
 asyncrefs=[x['addr'] for x in ins if ('0x358(gp)' in x['ops'] or 'gp, 0x358' in x['ops'])]
 assert asyncrefs==[0x7AAA,0x9F9E,0x9FAC],asyncrefs
 # All direct USB peripheral-base references belong to the classified roots.
 usb_lui=[x['addr'] for x in ins if x['mnem']=='lui' and '0x40023' in x['ops']]
 unclassified=[]
 for a in usb_lui:
  if not any(lo<=a<hi for lo,hi,_ in USB_ROOT_RANGES): unclassified.append(a)
 assert not unclassified,[hex(x) for x in unclassified]
 # No literal function pointer can bypass the classified call/USB-register audit.
 for va in [0x545A,0x5376,0x53F4,0x79BA,0x9F30,0xA0A8,0xA15A]: assert struct.pack('<I',va) not in blob,hex(va)
 # A8/A9 state split and latch set/clear/read.
 require_lines(ins,[(0x5322,['ori','0x8']),(0x532E,['sb','-0x760(gp)']),(0x5338,['sb','-0x761(gp)']),
 (0x533C,['sb','0x7(a5)']),(0x63EE,['sb','zero','-0x760(gp)']),(0x63F8,['lbu','-0x760(gp)']),
 (0x8600,['andi','-0x9']),(0x860C,['sb','0x7(a5)']),(0xA0AC,['lbu','-0x7f5(a5)']),(0xA0B0,['andi','0x8'])])
 # Builder mapping and actual analog field.
 require_lines(ins,[(0x9F60,['addi','0x44c']),(0x9FBE,['sb','0x4(a5)']),(0x9FC0,['sb','0x5(a5)']),
 (0x9FD8,['addi','0xec']),(0xA06A,['sb','0xb(a5)']),(0xA06E,['sb','0xc(a5)']),(0xA070,['sb','0xd(a5)']),
 (0xA072,['sb','0xe(a5)']),(0xA074,['sb','0xf(a5)']),(0xA078,['sb','0x10(a5)']),
 (0xA07A,['sb','0x11(a5)']),(0xA07E,['sb','0x12(a5)']),(0xA082,['sb','0x13(a5)'])])
 # Scan equation: absolute filtered delta / per-key float, cap 1600, store 0x2000444C.
 require_lines(ins,[(0xA388,['sub']),(0xA38C,['fcvt.s.w']),(0xA3A0,['flw']),
 (0xA3CC,['fdiv.s']),(0xA3D8,['flw']),(0xA3F8,['sh']),
 (0xA4F4,['fdiv.s']),(0xA510,['li','0x640']),(0xA514,['sh'])])
 assert abs(struct.unpack('<f',rd(blob,0xFB2C,4))[0]-1600.0)<1e-6
 assert abs(struct.unpack('<f',rd(blob,0xF7B0,4))[0]-0.39)<1e-5
 assert abs(struct.unpack('<f',rd(blob,0xFD74,4))[0]-10.0)<1e-6
 # Scale is updated as span/1600 and stored to the same 8-byte record.
 require_lines(ins,[(0xAB20,['fdiv.s']),(0xAF18,['fsw']),(0xAF7C,['fsw']),(0xADFC,['fsw'])])
 # Scheduler prioritizes control response before async response.
 require_lines(ins,[(0x79F2,['lbu','-0x7cb(gp)']),(0x79FA,['addi','-0x7af']),(0x7AB0,['jal','0x545a']),(0x7AE4,['jal','0x545a'])])
 # Descriptor map / thresholds.
 perm=list(rd(blob,0xFA94,72)); desc=rd(blob,0xFB74,216); thresholds=u16s(blob,0xFB48,22)
 descs=[desc[i*3:i*3+3] for i in range(72)]
 gaps=[i for i,d in enumerate(descs) if d[0]==0]
 assert gaps==[8,16,35,59] and len({d for d in descs if d[0]})==68
 # Tables.
 rows=[]
 for op,h in enumerate(jump):
  if op in ACTIVE: name,effect=ACTIVE[op][1],ACTIVE[op][2]
  else:name,effect='default_unknown','none'
  rows.append([f'0x{op:02X}',op,f'0x{h:08X}',int(h==DEFAULT),name,effect])
 csvw(out/'command_map_final.csv',['opcode','decimal','handler_va','is_default','meaning','side_effect_class'],rows)
 keyrows=[]
 for i,d in enumerate(descs):
  internal=perm[i]; keyrows.append([i,'' if internal==0xff else internal,keyname(d),d.hex(' '),int(d[0]==0)])
 csvw(out/'key_descriptor_map_final.csv',['scanner_slot','internal_id','key_name','descriptor','is_gap'],keyrows)
 csvw(out/'threshold_table_final.csv',['index','value','effective_by_sanitizer','note'],[[i,v,int(i<=12),'same 0..1600-domain threshold; indices >12 are sanitized'] for i,v in enumerate(thresholds)])
 packet=[
 ('0','u8','0xA0','async Hall packet header','proven'),('1..3','3 bytes','descriptor FB74[slot]','unique key identity','proven'),
 ('4..5','u16 BE','RAM 0x2000444C[slot]','PRIMARY LIVE ANALOG; firmware range 0..1600','proven'),
 ('6','u8','high byte 0x20004764','secondary quantized/gate value high','proven'),
 ('7','u8','conditional threshold/secondary low','state-dependent helper byte','proven structure'),
 ('8','u8','low byte 0x20004A7C','auxiliary','proven'),('9','u8','0x20004B9C','auxiliary','proven'),
 ('10','u8','record+4','per-key state','proven'),('11..13','decimal bytes','float record 0x200040EC','adaptive calibration scale; NOT primary analog','proven dataflow'),
 ('14..15','u16 BE','threshold table FB48[index]','actuation threshold in same internal domain','proven'),
 ('16..17','u16 BE','0x200043BC','auxiliary live word','proven'),('18..19','u16 BE','0x20003EAC','baseline/reference sample','proven'),
 ('20..63','bytes','not written by builder','stale/undefined; ignore','proven')]
 csvw(out/'a0_packet_format_final.csv',['bytes','encoding','source','meaning','confidence'],packet)
 ram=[
 ('0x20003CFC','u16[72]','raw/current Hall samples','baseline/filter input'),('0x20003EAC','u16[72]','baseline/reference','A0 bytes18..19'),
 ('0x20003F3C','u32[72]','filter accumulator','scan filter'),('0x200040EC','8-byte record[72]','float calibration scale + state','divides Hall delta; A0 bytes10..13'),
 ('0x200043BC','u16[72]','aux live','A0 bytes16..17'),('0x2000444C','u16[72]','primary normalized live coordinate 0..1600','A0 bytes4..5'),
 ('0x2000456C','u16[72]','telemetry mirror','change detector'),('0x20004644','u16[72]','telemetry trigger/source','change detector; values <=4 normalized to zero'),
 ('0x20004764','u16[72]','secondary quantized/gate value','copied to trigger; A0 bytes6..7'),('0x20004BE4','u8[72]','diagnostic/mode buffer','A8 fills FF; A9 clears'),
 ('0x20004D4C','8-byte config[72]','per-key configuration','threshold index and behavior'),('0x2000580B bit3','bit','telemetry latch','A8 sets; config init clears')]
 csvw(out/'hall_ram_dataflow_final.csv',['address','type','role','evidence/use'],ram)
 usb=[
 ('EP0','control','0x558E','standard USB + HID class only','no vendor control API, GET_REPORT stalls, no Feature report'),
 ('EP81','IN','0x7A10','boot keyboard','gp-0x794, 8 bytes'),('EP83','IN','0x7A50/78/98/CC','composite HID','mouse/NKRO/consumer/system'),
 ('EP82','IN','0x7AE4','vendor control response','gp+0x12C, AA/AB'),('EP82','IN','0x7AB0','vendor async','gp+0x358, only Hall producer'),
 ('EP04','OUT','0x558E -> 0x6226','vendor commands','single RX buffer, no queue')]
 csvw(out/'usb_control_data_paths_final.csv',['endpoint','direction','handler_or_sender','role','conclusion'],usb)
 irqs=[]
 for off,va in VECTOR_EXPECTED.items():
  role={0x66EA:'reset/main',0xDEF8:'peripheral IRQ; no USB base',0xB01A:'scan IRQ; calls Hall scan; no USB base',0x7AF4:'timer IRQ/scheduler tick; no direct USB base',0x558E:'USB IRQ/EP0/EP4 OUT'}[va]
  irqs.append([f'0x{off:X}',f'0x{va:X}',role])
 csvw(out/'interrupt_vector_audit_final.csv',['vector_file_offset','handler_va','classification'],irqs)
 activation=[
 (1,'passive listen','Do not mutate device; accept already active valid A0 packets.'),
 (2,'A9 then wait AA/A9','Normalize suppression=0 and clear diagnostic buffer.'),
 (3,'A8 then wait AA/A8','Arm latch and three forced sweeps. ACK alone is valid only after step 2.'),
 (4,'A9 then wait AA/A9','Minimize suppression interval; does not clear latch or forced-sweep counter.'),
 (5,'validate A0 snapshot','Require valid descriptors, values 0..1600, 68 unique physical keys across sweeps.'),
 (6,'steady state','Maintain last value per descriptor; raw=BE16(bytes4..5), normalized=clamp(raw,0,1600)/1600.'),
 (7,'failure recovery','Serialize retries; issue A9 on timeout/error; log all reports. Zero dropped keys is not statically guaranteed.')]
 csvw(out/'activation_state_machine_final.csv',['step','action','static rationale'],activation)
 confidence=[
 ('Exact image identity/base','proven','SHA/size/startup and all table addresses'),
 ('Only host-visible live Hall path is async A0 on EP82','proven for exact SHA','full opcode table + EP0 + all USB-register roots + all IN producers + IRQ audit'),
 ('Primary analog is A0 bytes4..5 BE u16','proven','builder source 0x2000444C; scan stores abs Hall delta/scale capped at 1600'),
 ('Normalize with /1600','proven internal domain','hard cap constant 1600.0 and store 0x640; physical millimeters not proven'),
 ('Bytes11..13 are calibration scale, not analog','proven','same float is divisor; updated as span/1600; default 0.39'),
 ('A9→A8→A9 serialized activation','strong static design','state split and RX/scheduler proven; physical timing/event loss needs hardware integration validation'),
 ('No lost letters during activation','not proven','A8 explicitly sets suppression until A9'),
 ('Behavior on other firmware/hardware revisions','not covered','must fingerprint VID/PID/bcd/build/SHA-compatible protocol behavior')]
 csvw(out/'confidence_matrix_final.csv',['claim','status','basis_or_limit'],confidence)
 facts={
 'schema':'mad68pr-final-static-audit-v2','firmware':{'size':len(blob),'sha256':sha,'image_base':'0x5000'},
 'usb':{'vid':'0x373B','pid':'0x1109','bcdDevice':'0x0102','vendor_interface':1,'in':'0x82','out':'0x04','report_bytes':64,'feature_report':False,'vendor_ep0_api':False},
 'dispatch':{'entries':243,'active':30,'active_opcodes':[f'0x{x:02X}' for x in sorted(ACTIVE)],'raw_5F_same_dispatch':True,'live_ram_read_opcode':False},
 'hall_transport':{'header':'0xA0','builder':'0x9F30','service':'0xA0A8','endpoint':'0x82','descriptor_table':'0xFB74','slots':72,'physical_keys':68,'gaps':gaps,'forced_sweeps':3,'then':'change-driven'},
 'analog':{'packet_bytes':'4..5','encoding':'big-endian u16','firmware_min':0,'firmware_max':1600,'normalization':'clamp(raw,0,1600)/1600.0','ram_source':'0x2000444C','scan_formula':'round_or_truncate(abs(filtered_sample-baseline)/per_key_scale), capped at 1600','bytes_11_13':'decimal serialization of per-key calibration scale, not primary analog'},
 'activation':{'arm':'0xA8','clear_suppression':'0xA9','recommended_serialized':['passive listen','A9 + AA/A9','A8 + AA/A8','A9 + AA/A9','validate A0'],'zero_key_loss_proven':False,'fire_and_forget_safe':False},
 'exhaustiveness':{'relevant_unknown_instructions':len(unknown),'interrupt_in_sender_calls':[f'0x{x:X}' for x in EXPECTED_CALLS[0x545A]],'usb_peripheral_lui_count':len(usb_lui),'usb_peripheral_unclassified':len(unclassified),'async_buffer_refs':[f'0x{x:X}' for x in asyncrefs],'ep0_vendor_api':False,'alternate_hall_usb_producer':False},
 'conclusion':'For this exact SHA, receive A0 on IF1 EP82 and use BE16 bytes4..5/1600. A8 is the only host command that arms the stream; commands must be serialized with A9 normalization/recovery.'}
 (out/'firmware_facts_final.json').write_text(json.dumps(facts,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
 print(json.dumps({'status':'ok','sha256':sha,'output':str(out),'conclusion':facts['conclusion']},indent=2,ensure_ascii=False))
 return 0
if __name__=='__main__': raise SystemExit(main())
