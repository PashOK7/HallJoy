# MADLIONS MAD 68 Pro R — углублённый статический аудит прошивки

**Статус:** окончательный статический аудит host-visible Hall/analog путей для исследованного образа.  
**Образ:** `35ed6b7a73cfe7e7fd222e6862032e49.bin`  
**SHA-256:** `2a7df4ffc491476b79da5333f51179f68fbbb5c5e146e987cfb5df764b79cead`  
**Размер:** `124656` байт (`0x1E6F0`)  
**База образа:** `0x5000`

Этот документ **заменяет Stage 1 и Stage 2**. В прежних документах были правильные находки, но также несколько недоказанных или ошибочных выводов. Они перечислены отдельно в разделе «Журнал исправлений».

---

## 1. Честный предел утверждения

Нельзя корректно заявить, что «идеально разобрана вся прошивка» в смысле полного восстановления исходного кода, имён всех функций, точной физической модели фильтра и поведения каждой подсистемы. Это потребовало бы исходников производителя, аппаратной трассировки и проверки на всех ревизиях платы.

Вместо этого выполнен более полезный и проверяемый для HallJoy объём:

1. восстановлена карта памяти и правильная база загрузки;
2. разобраны все USB-интерфейсы и HID report descriptors;
3. разобран весь vendor command dispatcher — **все 243 opcode `00..F2`**;
4. классифицированы все 30 активных opcode и их побочные эффекты;
5. найдены все прямые вызовы низкоуровневой отправки interrupt-IN;
6. восстановлены все producer’ы буферов USB IN;
7. восстановлена цепочка Hall scan → RAM → packet builder → vendor endpoint;
8. проверены все доступные host’у альтернативы получения live-аналоговых данных;
9. отделены доказанные факты от семантических предположений и того, что статически доказать нельзя.

### Итог в точной формулировке

Для **этого конкретного бинарного образа** можно считать статически доказанным следующее:

> `A0`-пакеты из асинхронного vendor-IN буфера — единственный реализованный прошивкой host-visible путь выдачи live Hall-данных. В активной command table нет запроса чтения live Hall RAM или адресного Hall polling; framing `0x5F` использует ту же таблицу; стандартные HID-интерфейсы не содержат аналогового отчёта; второго vendor-IN producer’а с Hall-данными нет.

Это не означает, что безопасная активация потока, отсутствие потерянных клавиш, длительность firmware tick или физическая единица float могут быть доказаны без исполнения на устройстве. Эти границы не скрываются.

---

## 2. Методика и воспроизводимость

Аудит выполнен непосредственно по байтам прошивки и дизассемблированному RV32-образу. В пакет входит `mad68pr_static_audit.py`, который не подключается к клавиатуре и проверяет:

- размер и SHA-256 файла;
- трансляцию VA/file offset;
- 243 элемента jump table;
- точные handler VA для всех 30 активных opcode;
- отсутствие других активных opcode;
- число уникальных обработчиков;
- permutation и четыре пустых scanner slot;
- фиксированную hidden-stream descriptor table и две соседние variant table;
- число уникальных дескрипторов;
- USB device/config/report descriptors;
- все прямые call-site’ы `0x545A`, `0x9F30`, `0xA0A8`, `0xA15A`, `0xA1A4`;
- все явные обращения к async TX buffer `gp+0x358`.

Команда воспроизведения анализа разработчиком:

```text
python3 mad68pr_static_audit.py \
    35ed6b7a73cfe7e7fd222e6862032e49.bin \
    fw_rv32_base5000.disasm.txt \
    output
```

Это **инструмент аудита**, а не требование к пользователю HallJoy. Будущая версия HallJoy не должна зависеть от Python.

---

## 3. Архитектура и карта памяти

### 3.1 ISA

В образе наблюдаются:

- little-endian RV32;
- compressed instructions;
- integer multiply/divide;
- floating point instructions;
- WCH/QingKe-specific CSR/расширения.

### 3.2 Правильная база

```text
virtual_address = file_offset + 0x5000
file_offset     = virtual_address - 0x5000
```

Именно неверная база была причиной первоначального вывода о «вырезанной» jump table. Например:

```text
jump table VA     0xF2C0
file offset       0xA2C0
```

### 3.3 Startup RAM layout

Статический startup задаёт:

```text
gp = 0x200032A0
sp = 0x20008000
```

Инициализированные данные копируются:

```text
flash VA 0x11508 → RAM 0x20000000..0x20002AC0
```

BSS очищается:

```text
RAM 0x20002AC0..0x20005C48
```

Это позволяет однозначно вычислять абсолютные адреса выражений вида `gp±offset`.

---

## 4. USB topology

### 4.1 Device descriptor

- VID: `0x373B`
- PID: `0x1109`
- bcdDevice: `0x0102`
- product: `MAD 68 Pro R`
- build strings: `Apr 15 2025`, `14:30:22`
- EP0 packet: 64 байта

### 4.2 Configuration descriptor

Прошивка объявляет три HID-интерфейса.

| IF | Назначение | Endpoints | Packet |
|---:|---|---|---:|
| 0 | Boot keyboard | `0x81 IN` | 8 |
| 1 | Vendor HID | `0x82 IN`, `0x04 OUT` | 64 |
| 2 | Composite HID | `0x83 IN` | до 64 |

### 4.3 Vendor HID report descriptor

Interface 1 содержит:

- Generic Desktop Usage Page;
- vendor-style usage `0`;
- 64-байтовый Input report;
- 64-байтовый Output report;
- **нет Feature report**;
- нет report ID на уровне device report.

Windows/hidapi может добавлять host-side нулевой report-ID байт, поэтому API write buffer часто имеет 65 байт, но firmware payload остаётся 64-байтовым.

### 4.4 Standard HID не выдаёт аналог

Interface 2 содержит:

- report ID 1 — NKRO keyboard, usages до `0x7C`;
- report ID 2 — mouse;
- report ID 3 — consumer;
- report ID 4 — system;
- report ID 5 — один дополнительный bit usage.

Ни IF0, ни IF2 не имеют массива analog axes, vendor analog usages или per-key analog report. Таким образом, стандартный HID-путь исключён как источник полного Hall travel.

---

## 5. Vendor OUT receive path

Endpoint `0x04 OUT` принимает отчёт следующим образом:

1. проверяет длину `<=64`;
2. копирует endpoint buffer в **единственный** software buffer `gp+0x12C`;
3. сохраняет длину в `gp-0x7C4`;
4. устанавливает pending flag `gp-0x7CA`.

### Критическое следствие

В прошивке нет очереди команд и нет второго RX command buffer. Если host отправит два OUT-report подряд быстрее обработки первого, второй может перезаписать software buffer либо схлопнуться с pending state.

Поэтому прежняя рекомендация «послать `A8`, затем `A9` немедленно, не ожидая ответа» **не является статически безопасной**. Любая реализация HallJoy должна сериализовать команды и подтверждать переход состояния, а не использовать fire-and-forget burst.

---

## 6. Vendor framing и parser

Parser находится по VA `0x6226`.

### 6.1 Нормальный request

| Byte | Значение |
|---:|---|
| 0 | `0x55` request |
| 1 | opcode |
| 2 | XOR key; `0` = без XOR |
| 3 | checksum |
| 4 | payload length, максимум `0x38` |
| 5–6 | offset/index, little-endian |
| 7 | parameter/flags |
| 8… | payload |

Checksum:

```text
sum(packet[4 .. 7+length]) & 0xFF
```

При ненулевом XOR key расшифровываются bytes `3..7+length`, то есть зашифрованы checksum, length, offset, flags и payload.

### 6.2 Response

- `0xAA` — принятый normal request;
- `0xAB` + `cserr` — checksum error;
- default handler возвращает `unknw`;
- control response передаётся той же длиной, с которой был принят OUT report.

### 6.3 Header `0x5F`

`0x5F` обходит normal `0x55`/checksum gate, но после этого:

- opcode берётся из byte 1;
- ограничивается `<=0xF2`;
- используется **та же** jump table по `0xF2C0`.

Следовательно, `0x5F` не открывает скрытый второй dispatcher, произвольное чтение RAM или дополнительный Hall protocol.

---

## 7. Полная command table

Jump table:

```text
VA          0xF2C0
entries     243 (`00..F2`)
entry size  4 bytes, absolute handler VA
```

- активных opcode: 30;
- default opcode: 213;
- уникальных handler VA: 31 с default;
- скрытых активных entries вне перечисленных ниже нет.

### 7.1 Активные read/config команды

| Opcode | Назначение |
|---:|---|
| `03` | версия и build strings |
| `04` | read logical NVM `0x235F0 + byte5` |
| `05` | read logical NVM `0x20100 + byte5` |
| `07` | read immutable/default table `0x108A8 + offset` |
| `08` | read logical NVM `0x225F0 + offset` |
| `0A` | read logical NVM `0x20200 + offset` |
| `0C` | read logical NVM `0x215F0 + offset` |
| `A0` | read logical NVM `0x20400 + offset` |
| `A2` | read logical NVM `0x20800 + offset` |
| `A4` | read logical NVM `0x20BF0 + offset` |
| `A6` | read logical NVM `0x20CF0 + offset` |
| `B0` | read logical NVM `0x20000 + offset` |
| `DE` | read runtime RAM `0x2000514C + offset`, max `0x180` |
| `F1` | read logical NVM `0x21DF0 + offset` |

Ни один из этих обработчиков не адресует live Hall arrays `0x20003CFC..0x20004Bxx`.

### 7.2 Write/опасные команды

| Opcode | Назначение | Риск |
|---:|---|---|
| `06` | write `0x20100`, reload/validation/reset path | flash/reset |
| `09` | write `0x225F0`, max `0x1000` | flash |
| `0B` | write `0x20200`, max `0x180` | flash/data-flash |
| `0D` | write `0x215F0`, max `0x1000` | flash |
| `A1` | write Hall config `0x20400`, then reload/sanitize | flash/config |
| `A3` | write `0x20800`, max `0x400` | flash |
| `A5` | write `0x20BF0`, max `0x100` | flash |
| `A7` | write `0x20CF0`, max `0x100` | flash |
| `B1` | write `0x20000`; локальный bound не виден | критический |
| `DD` | write runtime RAM `0x200052CC`, max `0x180` | runtime state |
| `EE` | maintenance/factory arm; связан с destructive restore | никогда не probe |
| `F2` | write `0x21DF0`, max `0x400` | flash |

### 7.3 Volatile state commands

| Opcode | Назначение |
|---:|---|
| `01` | установить runtime flag `gp-0x7CC` |
| `02` | очистить runtime flag `gp-0x7CC` |
| `A8` | включить Hall telemetry state, suppression и 3 sweeps |
| `A9` | очистить suppression flag и 72-byte diagnostic buffer |

Полная таблица всех 243 opcode находится в `mad68pr_command_map_audited.csv`.

---

## 8. Доказательство, что `0B` — не безопасный RAM framebuffer

Обработчик `0B` вызывает helper `0x5F7E`.

Он:

1. читает offset и payload length;
2. проверяет `offset + length <= 0x180`;
3. строит logical address `0x20200 + offset`;
4. OR’ит адрес с `0x08000000`;
5. вызывает flash/data-flash writer `0xDFF4`.

`0xDFF4` обрабатывает диапазон `0x08020000..0x08040000` и выполняет page erase/program по 256-байтовым страницам.

Следовательно, независимо от того, как сторонние RGB-программы используют opcode `0B`, статически он не является простой записью в volatile RGB framebuffer. Его нельзя применять как безопасный диагностический probe; частые записи потенциально затрагивают endurance data-flash.

---

## 9. Полный аудит USB IN producer’ов

Низкоуровневая функция interrupt-IN send: VA `0x545A`.

Во всём дизассемблированном коде найдено ровно семь прямых call-site’ов, все в scheduler `0x79BA`:

```text
0x7A10
0x7A50
0x7A78
0x7A98
0x7AB0
0x7ACC
0x7AE4
```

Ни одного literal function pointer на `0x545A` в образе нет.

### 9.1 Scheduler mapping

| Endpoint | Buffer | Length | Содержимое |
|---|---|---:|---|
| `0x81` | `gp-0x794` | 8 | boot keyboard |
| `0x83` | `gp-0x7C0` | 6 | report ID 2 / mouse-like |
| `0x83` | `gp+0x418` | 16 | report ID 1 / NKRO keyboard |
| `0x83` | `gp-0x7B4` | 3 | report ID 3 / consumer |
| `0x83` | `gp-0x778` | 3 | report ID 4/5 / system |
| `0x82` | `gp+0x12C` | received length | vendor control `AA/AB` |
| `0x82` | `gp+0x358` | 64 | vendor async `A0` |

### 9.2 Уникальность async vendor buffer

Явные обращения к `gp+0x358` во всём коде находятся только в трёх местах:

```text
0x7AAA  scheduler берёт адрес для EP82 IN
0x9F9E  packet builder получает base pointer
0x9FAC  packet builder записывает byte0 = 0xA0
```

Builder `0x9F30` имеет только два call-site’а:

```text
0xA126
0xA13A
```

Оба находятся внутри service `0xA0A8`.

Service `0xA0A8` имеет только один call-site:

```text
0x86EC — main service loop
```

Это формирует замкнутую и исчерпывающую цепочку единственного async vendor producer’а.

---

## 10. Hall scan dataflow

Полный Hall processing routine начинается около VA `0xA2A2` и проходит 72 scanner slot.

Статически восстановленные ключевые RAM-массивы:

| Address | Shape | Роль |
|---|---|---|
| `0x20003CFC` | 72 × u16 | raw Hall/ADC-like samples |
| `0x20003EAC` | 72 × u16 | baseline/reference |
| `0x20003F3C` | 72 × u32 | filter accumulator |
| `0x200040EC` | 72 × 8 bytes | float analog-metric/state record |
| `0x200043BC` | 72 × u16 | auxiliary live word |
| `0x2000444C` | 72 × u16 | primary live word |
| `0x2000456C` | 72 × u16 | telemetry mirror |
| `0x20004644` | 72 × u16 | telemetry change source/state magnitude |
| `0x20004764` | 72 × u16 | secondary live/gate word |
| `0x20004A7C` | 72 × u16 | auxiliary word |
| `0x20004B9C` | 72 × u8 | auxiliary byte |
| `0x20004BE4` | 72 × u8 | diagnostic/mode buffer |
| `0x20004D4C` | 72 × 8 bytes | active Hall/actuation config records |

### 10.1 Baseline initializer `0xA15A`

Для всех 72 slot:

```text
raw = u16[0x20003CFC + 2*i]
baseline[i] = raw
filter_accumulator[i] = (raw << 4) + (raw >> 1)
```

То есть accumulator инициализируется приблизительно `raw * 16.5`.

### 10.2 Float/state record

Builder читает:

```text
float  @ 0x200040EC + 8*i
state  @ 0x200040EC + 8*i + 4
```

Scan routine записывает в ту же структуру и применяет floating-point константы/пороги. Это доказывает, что сериализованный float является вычисленной per-key analog metric, связанной с Hall state machine, но точную физическую единицу нельзя объявлять доказанной только по инструкциям.

---

## 11. Per-key Hall configuration

Loader/sanitizer: VA `0xA1A4`.

Он копирует:

```text
logical NVM 0x20400 → RAM 0x20004D4C
```

Размер — `0x400`, после чего проверяются 72 записи по 8 байт.

### 11.1 Проверки записи

- signature: `(u16@+0 & 0xE0) == 0xA0`;
- low 5 bits — threshold index;
- допустимый threshold index: `0..12`;
- индекс `>12` заменяется на `9`;
- mode bits ограничиваются допустимым диапазоном;
- actuation/rapid-trigger поля ограничиваются выбранным threshold;
- некорректные записи заменяются/санитизируются default values.

### 11.2 Threshold table

Threshold table находится по VA `0xFB48` и физически содержит 22 u16 значения. Однако effective indices per-key config ограничены `0..12`. Значения `13..21` присутствуют рядом в image, но валидная запись Hall config не может выбрать их без последующей замены индекса на `9`.

---

## 12. Hidden telemetry arm: opcode `A8`

Dispatch:

```text
A8 → handler 0x63F8 → helper 0x530E
```

`0x530E` выполняет:

1. `config[7] |= 0x08`, абсолютный byte `0x2000580B` bit 3;
2. `gp-0x760 = 1`;
3. `gp-0x761 = 3`;
4. `memset(0x20004BE4, 0xFF, 72)`;
5. вызывает baseline initializer `0xA15A`.

### 12.1 Значение состояний

- `0x2000580B bit3` — gate telemetry service;
- `gp-0x761` — forced sweep counter;
- `gp-0x760` — отдельное состояние, которое изменяет/обрывает normal key processing path;
- `0x20004BE4[72]` — diagnostic/mode state, exact full semantics не восстановлена.

---

## 13. Opcode `A9` и suppression

`A9`:

```text
gp-0x760 = 0
memset(0x20004BE4, 0, 72)
```

Он не выполняет явную операцию очистки telemetry bit3 и не очищает forced sweep counter.

### 13.1 Почему нельзя обещать отсутствие потерянного ввода

Scan routine проверяет `gp-0x760`, в частности по VA `0xAA6A` и `0xAB72`. При ненулевом значении происходят переходы, обходящие части normal processing path.

Следовательно:

- A8 действительно включает interval изменённого/подавленного normal processing;
- A9 возвращает это состояние в zero;
- статически нельзя доказать, что между A8 и обработанным A9 не потеряется ни одного key event;
- длительность interval зависит от USB parser scheduling, scan scheduling и hardware tick.

### 13.2 Почему нельзя отправлять A8/A9 подряд без ACK

Из-за единственного RX software buffer `gp+0x12C` и одного pending flag нет гарантии, что два последовательных OUT-report будут обработаны как очередь. Поэтому корректный future transport должен быть command/response state machine, а не burst.

### 13.3 Очистка telemetry latch

Прежнее утверждение «latch очищается только power cycle» неверно.

Config initialization около VA `0x85FA..0x860C` выполняет:

```text
config[7] &= ~0x08
```

То есть повторная инициализация/загрузка конфигурации также очищает telemetry bit. Отдельного доказанного безопасного opcode «clear only telemetry bit» в command table не найдено.

---

## 14. Telemetry service `0xA0A8`

Service вызывается из main service loop по `0x86EC`.

### 14.1 Gates

Перед формированием пакета проверяются:

1. `0x2000580B bit3`;
2. async buffer ready/busy flag `gp-0x7AF`;
3. timer helper с threshold `15` firmware ticks.

Длительность одного tick статически не установлена. Формулировка «15 ms» недоказана.

### 14.2 Forced sweep mode

Если `gp-0x761 != 0`:

- slot index хранится в `gp-0x75C`;
- service вызывает builder для одного slot за одну eligible итерацию;
- slot проходит `0..71`;
- после полного прохода counter уменьшается;
- A8 начинает с counter `3`.

Builder сам пропускает нулевой descriptor, поэтому за полный проход формируется 68 полезных key packet.

### 14.3 Change-driven mode

Если forced sweep counter равен нулю:

- source: `0x20004644[72]`;
- mirror: `0x2000456C[72]`;
- source values `<=4` нормализуются к zero перед сравнением;
- при первом изменении mirror обновляется;
- builder вызывается для первого изменившегося slot;
- максимум один изменившийся slot отправляется за eligible service opportunity.

Это event/change stream, а не host-requested polling.

---

## 15. Packet builder `0x9F30`

Input — scanner slot `0..71`.

### 15.1 Descriptor и gap

Builder всегда использует фиксированную таблицу:

```text
VA 0xFB74
72 × 3 bytes
```

Если descriptor byte0 равен zero, builder возвращается, не выставляя ready flag. Это четыре gap slot.

### 15.2 Buffer

Output buffer:

```text
gp+0x358
```

Firmware явно записывает только bytes `0..19`. Bytes `20..63` не очищаются builder’ом и должны считаться stale/undefined.

### 15.3 Точный формат полезной части

| Byte | Источник/значение |
|---:|---|
| 0 | `0xA0` |
| 1–3 | descriptor table `0xFB74 + 3*slot` |
| 4–5 | `u16 0x2000444C[slot]`, big-endian |
| 6 | high byte `u16 0x20004764[slot]` |
| 7 | conditional threshold/state low byte |
| 8 | low byte `u16 0x20004A7C[slot]` |
| 9 | `u8 0x20004B9C[slot]` |
| 10 | state byte `0x200040EC + 8*slot + 4` |
| 11 | integer part of float travel/state |
| 12 | tenths digit |
| 13 | hundredths digit |
| 14–15 | selected threshold, big-endian |
| 16–17 | `u16 0x200043BC[slot]`, big-endian |
| 18–19 | baseline `u16 0x20003EAC[slot]`, big-endian |

### 15.4 Float serialization

Firmware выполняет truncation и последовательное умножение fractional part на `10.0`.

Host reconstruction:

```text
value = byte11 + byte12 / 10 + byte13 / 100
```

Это точная арифметика сериализации. Метрика динамически вычисляется Hall state machine и пригодна как аналоговый сигнал. Называть её физическим ходом в миллиметрах без runtime-сопоставления нельзя.

### 15.5 Byte 7

Builder выбирает byte7 условно:

- получает selected threshold;
- сравнивает secondary live value с `threshold - 8`;
- учитывает `0x20004644[slot]` и границу `5`;
- пишет либо low threshold, либо zero, либо low live value.

Поэтому bytes6–7 нельзя безусловно декодировать как один обычный big-endian u16.

---

## 16. Descriptor tables и карта клавиш

### 16.1 Fixed hidden-stream table

Builder использует исключительно `0xFB74`.

- 72 triples;
- zero descriptors: slots `8,16,35,59`;
- 68 nonzero descriptors;
- все 68 nonzero descriptors уникальны.

### 16.2 Permutation

Permutation table `0xFA94`:

- 72 bytes;
- `0xFF` в тех же slots `8,16,35,59`;
- остальные значения — уникальная перестановка `0..67`.

Это связывает scanner slot с internal physical ID.

### 16.3 Variant tables

В image есть ещё две 72×3 таблицы:

- `0x108A8` — immutable/default table;
- `0x10CA8` — alternate table.

Они отличаются в нескольких slot, включая international/modifier/Fn варианты. Однако hidden packet builder не содержит выбора между ними: он адресует `0xFB74` непосредственно. Поэтому именно `0xFB74` является authoritative для hidden `A0` stream данной сборки.

Все три таблицы сведены в `mad68pr_descriptor_variants_audited.csv`.

---

## 17. Проверка всех альтернативных путей получения аналога

### 17.1 Standard boot keyboard `0x81`

Передаёт 8-байтовый boot keyboard report. Аналоговых значений нет.

**Результат:** исключён.

### 17.2 Composite HID `0x83`

Передаёт NKRO/mouse/consumer/system reports, определённые descriptor’ом. Полного per-key analog массива нет.

**Результат:** исключён.

### 17.3 Vendor control command `0x82`

Полностью перечислены все активные opcode. Read handlers адресуют NVM/config либо отдельный runtime buffer `0x2000514C`, но не live Hall arrays.

**Результат:** host-addressed live Hall polling отсутствует.

### 17.4 Header `0x5F`

Использует тот же opcode dispatch.

**Результат:** дополнительного hidden read API нет.

### 17.5 Opcode `DE`

Читает RAM `0x2000514C`, max `0x180`. Это не Hall config `0x20004D4C` и не один из live Hall arrays, используемых builder’ом.

**Результат:** не live Hall transport.

### 17.6 Opcode `DD`

Пишет другой RAM buffer `0x200052CC`, max `0x180`.

**Результат:** не read path и не Hall live array.

### 17.7 Vendor async buffer

Единственный async vendor buffer строится `0x9F30`, его поля читаются из Hall scan RAM и маркируются `0xA0`.

**Результат:** единственный найденный host-visible live Hall transport.

---

## 18. Полная доказательная цепочка

```text
Hall acquisition / filtering
    ↓
main Hall scan 0xA2A2...
    ↓ writes
0x200040EC / 0x200043BC / 0x2000444C /
0x20004644 / 0x20004764 / auxiliary arrays
    ↓
telemetry service 0xA0A8
    ↓ calls only
packet builder 0x9F30
    ↓ writes only
async buffer gp+0x358, header A0, bytes0..19
    ↓ consumed only by
USB scheduler 0x7AA4
    ↓
interrupt IN endpoint 0x82, 64 bytes
```

Обратная проверка:

```text
all endpoint IN sends
    → 7 call-sites in one scheduler
    → only two EP82 sources
       1. control buffer gp+0x12C
       2. async buffer gp+0x358
    → async buffer has one builder
    → builder has one service caller
    → service is fed by Hall scan arrays
```

Именно эта двусторонняя проверка — от сенсоров к USB и от USB назад к producer’ам — позволяет делать исчерпывающий вывод о host-visible analog path.

---

## 19. Уровни уверенности

### 19.1 Статически доказано для этого SHA-256

- image base `0x5000`;
- USB topology и report descriptors;
- framing/checksum/XOR;
- jump table и все активные opcode;
- отсутствие альтернативного dispatcher у `0x5F`;
- все direct interrupt-IN send call-site’ы;
- единственный async vendor TX buffer;
- единственный builder этого buffer;
- Hall-derived RAM fields в `A0` packet;
- fixed descriptor table `0xFB74`;
- 68 keys/4 gaps;
- A8/A9 state writes;
- A8 включает suppression state;
- config initialization очищает telemetry bit;
- `0B` вызывает flash/data-flash writer;
- отсутствует active command, читающая live Hall RAM.

### 19.2 Высокая уверенность, но семантическое имя частично inferred

- float `0x200040EC` — динамическая per-key analog metric, связанная с Hall state machine;
- threshold/config fields относятся к actuation/rapid-trigger;
- auxiliary words представляют стадии Hall filter/state machine.

### 19.3 Не доказано статически

- физическая единица float (`mm` или internal scaled unit);
- точная длительность firmware tick;
- реальная пропускная способность stream при одновременной печати;
- число потерянных key events во время A8→A9 transition;
- поведение на другой hardware/firmware revision с иным SHA;
- гарантия, что OS HID stack не вносит дополнительные особенности доставки.

---

## 20. Журнал исправлений относительно Stage 2

### Исправление 1: A8→A9 fire-and-forget

**Раньше:** рекомендовалось отправить A8 и A9 немедленно без ожидания ACK.  
**Теперь:** отозвано. Есть один RX buffer и один pending flag, поэтому необходима сериализация.

### Исправление 2: отсутствие dropped input

**Раньше:** предполагалось, что A9 сразу оставляет stream без заметного влияния на input.  
**Теперь:** статически доказан suppression branch; zero-drop activation не доказана.

### Исправление 3: сброс latch только питанием

**Раньше:** считалось, что telemetry latch очищается только power cycle.  
**Теперь:** config init `0x85FA..0x860C` также очищает bit3.

### Исправление 4: адрес Hall config RAM

**Раньше:** некоторые заметки смешивали `0x20004D4C` и `0x200052CC`.  
**Теперь:** per-key Hall config находится в `0x20004D4C`; `0x200052CC` — отдельный DD runtime write buffer.

### Исправление 5: opcode `0B`

**Раньше:** назван direct RGB framebuffer.  
**Теперь:** статически доказан вызов data-flash writer. Команда не считается безопасной volatile write.

### Исправление 6: descriptor variants

**Раньше:** таблицы могли трактоваться как runtime-selected variants hidden stream.  
**Теперь:** builder напрямую использует fixed `0xFB74`; соседние tables существуют, но hidden builder их не выбирает.

---

## 21. Требования к будущему HallJoy backend

Это не реализация, а ограничения, полученные из firmware audit.

1. Не требовать Python, браузер или ручной capture от пользователя.
2. Сначала пассивно слушать IF1/EP82: latch может уже быть активен.
3. Демультиплексировать `AA`, `AB`, `A0` по byte0.
4. Никогда не probe’ить write/factory opcode.
5. Не использовать `0B` как безопасный тест.
6. Сериализовать control commands: один outstanding request, timeout, opcode/response correlation.
7. Не отправлять A8/A9 burst’ом.
8. Явно учитывать возможный короткий input suppression interval.
9. Принимать только A0 packets с descriptor из fixed table `0xFB74`.
10. Игнорировать bytes20..63.
11. Вести state snapshot по 68 keys.
12. Сохранять подробный troubleshooting log:
    - enumeration interfaces/usage/endpoint;
    - report lengths;
    - passive A0 detection;
    - каждую control transaction;
    - checksum/AB/timeout;
    - interleaved A0/AA sequence;
    - descriptor validation;
    - sweep completeness;
    - value ranges и изменение при input;
    - suppression recovery;
    - disconnect/reconnect.
13. Не объявлять backend working только по ACK A8. Критерий — валидные A0 descriptors и завершённый 68-key snapshot либо диагностически объяснённая деградация.
14. Для неизвестного firmware SHA использовать conservative compatibility mode и не выполнять write/factory commands.

---

## 22. Финальный вывод

Полностью восстановить каждую внутреннюю функцию прошивки до исходного C-кода не заявляется. Однако именно область, необходимая для HallJoy — **все host-visible способы получить live Hall/analog data** — проверена исчерпывающе для исследованного SHA.

Найденный механизм не является QBZ-подобным host-addressed polling. Это firmware-driven, address-tagged, change-driven `A0` stream на vendor endpoint `0x82`, с тремя forced sweeps после A8.

Другого реализованного пути live Hall readout в этом образе нет:

- не в standard HID;
- не в vendor control opcode;
- не через `0x5F`;
- не через DD/DE;
- не через второй async producer.

При этом прежний «пробник A8/A9 без ожидания» недостаточно надёжен и не должен перекладываться на пользователей. Следующий этап должен быть не ручной тест, а встроенный self-diagnosing HallJoy backend, который применяет только доказанные read/volatile paths, сериализует переходы, обнаруживает stream пассивно, восстанавливает ввод и пишет детальный лог.

---

## 23. Артефакты

- `mad68pr_static_audit.py` — воспроизводимые assertions по firmware/disassembly;
- `tables/mad68pr_firmware_facts.json` — машинно-читаемые выводы и границы;
- `tables/mad68pr_command_map_audited.csv` — все 243 opcode;
- `tables/mad68pr_descriptor_variants_audited.csv` — fixed и variant descriptors;
- `tables/mad68pr_hall_ram_map_audited.csv` — Hall RAM dataflow;
- `tables/mad68pr_threshold_table_audited.csv` — physical/effective threshold indices;
- `tables/mad68pr_usb_producer_graph.csv` — все endpoint producer paths;
- `evidence/` — точные дизассемблерные фрагменты и raw descriptor/table bytes;
- `MANIFEST.json` — SHA-256 всех файлов пакета.
