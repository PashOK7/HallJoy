# MADLIONS MAD 68 Pro R — скрытый Hall-поток из прошивки

Статус: статический реверс прошивки, этап 2.  
Этот документ **заменяет выводы этапа 1 о пустой таблице команд и предполагаемых opcode `0F/0E`**.

## 1. Исследованный образ

- файл: `35ed6b7a73cfe7e7fd222e6862032e49.bin`
- размер: `124656` байт (`0x1E6F0`)
- SHA-256: `2a7df4ffc491476b79da5333f51179f68fbbb5c5e146e987cfb5df764b79cead`
- архитектура: WCH/QingKe RV32 с M/A/F/C/XWCHC
- база образа во flash: **`0x5000`**

Критическая поправка:

```text
virtual_address = file_offset + 0x5000
file_offset     = virtual_address - 0x5000
```

Из-за неверной базы на первом этапе таблицу по VA `0xF2C0` искали по file offset `0xF2C0`, где действительно были нули. Правильный offset — `0xA2C0`; таблица полностью присутствует.

## 2. USB-интерфейс

- VID/PID: `373B:1109`
- product: `MAD 68 Pro R`
- vendor HID interface: `1`
- interrupt OUT: `0x04`
- interrupt IN: `0x82`
- размер device report: 64 байта
- для `hidapi` в Windows запись обычно содержит дополнительный нулевой report ID и имеет 65 байт

Обычный управляющий пакет:

| Offset | Поле |
|---:|---|
| 0 | `55` request; `AA` нормальный response; `AB` checksum error; `5F` raw/internal framing |
| 1 | opcode |
| 2 | XOR key; `0` без XOR |
| 3 | checksum |
| 4 | payload length, максимум `0x38` |
| 5–6 | offset, little-endian |
| 7 | parameter/flags |
| 8… | payload |

Checksum — сумма байтов `4 .. 7+length` modulo 256. При XOR шифруются байты `3 .. 7+length`; длина тоже зашифрована.

`0x5F` не открывает отдельный набор диагностических обработчиков. Он только обходит обычную проверку `55/checksum`, затем использует **ту же jump table opcode**.

## 3. Точная таблица команд

Parser: VA `0x6226`, file offset `0x1226`.  
Jump table: VA `0xF2C0`, file offset `0xA2C0`, 243 записи для opcode `00..F2`.

В таблице только 31 уникальный обработчик. Все неизвестные opcode идут в default handler VA `0x66BE`.

Ключевые команды:

| Opcode | Handler VA | Назначение |
|---:|---:|---|
| `0B` | `0x6532` | direct RGB framebuffer chunks |
| `A0/A1` | `0x64BE/0x64BA` | read/write фиксированного config/flash window около `0x20400` |
| `A2/A3` | `0x6482/0x647E` | read/write window около `0x20800` |
| `A4/A5` | `0x6446/0x6442` | read/write window около `0x20BF0` |
| `A6/A7` | `0x640A/0x6406` | read/write window около `0x20CF0` |
| **`A8`** | **`0x63F8`** | latch скрытой Hall-телеметрии и запуск трёх полных проходов |
| **`A9`** | **`0x63E0`** | очистить отдельное состояние подавления обычного ввода |
| `B0/B1` | `0x63A8/0x63A4` | ещё одна config read/write pair |
| `F1` | `0x635C` | чтение фиксированного config window |

Полная карта находится в `mad68pr_command_map.csv`.

### Вывод о request/response polling

В jump table этой сборки **нет обработчика host-addressed чтения live Hall RAM** и нет команды, принимающей номер scanner slot и возвращающей его текущее значение. `A0–A7`, `B0/B1` и `F1` читают фиксированные конфигурационные/flash-окна, а не массивы live scan в RAM `0x20004xxx`.

Незаявленный live-протокол реализован иначе: клавиатура выдаёт асинхронный адресованный packet-stream на том же vendor IN endpoint.

## 4. Разделённые состояния A8/A9

### `A8` → VA `0x63F8` → VA `0x530E`

Функция:

1. устанавливает bit 3 в volatile RAM config byte `0x2000580B`;
2. устанавливает `gp-0x760 = 1` — состояние, которое меняет/подавляет обычную обработку клавиш;
3. устанавливает `gp-0x761 = 3` — три принудительных прохода по 72 scanner slots;
4. заполняет 72-байтовый diagnostic buffer `0x20004BE4` значением `FF`;
5. вызывает baseline initialization VA `0xA15A`.

### `A9` → VA `0x63E0`

Функция:

1. очищает `gp-0x760`;
2. обнуляет 72-байтовый buffer `0x20004BE4`;
3. **не очищает** bit 3 в `0x2000580B`;
4. **не очищает** forced-sweep counter `gp-0x761`.

В scan path по VA `0xAA6A` именно `gp-0x760` проверяется перед обычной обработкой клавиш. Поэтому последовательность:

```text
A8
A9 немедленно следом
```

разделяет две функции, которые официальный режим использует вместе:

- обычный буквенный ввод возвращается после `A9`;
- скрытая телеметрия остаётся включённой из-за volatile bit 3;
- три полных прохода продолжаются после `A9`;
- затем поток становится change-driven.

Это не использование страницы калибровки и не удержание клавиатуры в калибровочном режиме. Это скрытая state-split последовательность, найденная непосредственно в прошивке.

### Управляющие пакеты

64-байтовый request `A8`:

```text
55 A8 00 00 00 00 00 00 00 ...
```

64-байтовый request `A9`:

```text
55 A9 00 00 00 00 00 00 00 ...
```

Для Windows `hidapi` перед ними добавляется report ID `00`.

Практический порядок:

```text
send A9             // очистить возможное старое состояние
send A8
send A9 immediately // не ждать ACK A8
```

Тестовая утилита использует gap 0.5 ms, настраиваемый до 0. Последний `A9` также повторяется в cleanup.

### Отключение

`A9` восстанавливает обычный input, но не выключает telemetry latch. Bit 3 очищается startup-кодом по VA `0x85FC`. Надёжный способ полного отключения — USB power-cycle клавиатуры. В найденном протоколе нет подтверждённой безопасной команды clear-latch без перезапуска.

Ни одна команда записи flash для запуска потока не нужна и тестовой утилитой не используется.

## 5. Асинхронный скрытый отчёт `A0`

Builder: VA `0x9F30`, file offset `0x4F30`.  
Service: VA `0xA0A8`, file offset `0x50A8`.  
Вызов из main loop: VA `0x86EC`.  
Отдельный TX buffer: `gp+0x358`.  
Busy/ready flag: `gp-0x7AF`.  
Передача: фиксированные 64 байта на vendor IN endpoint `0x82`.

Это отдельный буфер, независимый от обычных `AA` control responses (`gp+0x12C`). Host должен демультиплексировать входящие reports по первому байту:

- `AA/AB` — control response;
- `A0` — hidden Hall telemetry.

### Scheduler

Service проверяет:

1. volatile config bit 3;
2. что предыдущий async report уже отправлен;
3. elapsed threshold = 15 firmware ticks.

Реальная длительность одного firmware tick статически не доказана, поэтому нельзя честно называть это 15 ms без аппаратной телеметрии.

Режимы:

- `gp-0x761 != 0`: последовательно отправляется slot `0..71`; после полного прохода счётчик уменьшается. `A8` задаёт 3 прохода.
- `gp-0x761 == 0`: сравниваются текущий и mirror-массивы 72 каналов; отправляется первый изменившийся slot, mirror обновляется.

Идентификатор клавиши находится в каждом пакете, поэтому поток адресованный, хотя host не задаёт адрес запросом.

## 6. Формат полезных байтов `A0`

Прошивка явно записывает только bytes `0..19`. Bytes `20..63` могут содержать старые данные TX buffer и должны игнорироваться.

| Byte | Значение |
|---:|---|
| 0 | `A0` |
| 1 | descriptor type (`10` для обычной клавиши/модификатора, `F0` для Fn) |
| 2 | modifier mask или descriptor byte |
| 3 | HID usage или special subcode |
| 4–5 | primary live value, big-endian `u16`, RAM `0x2000444C + 2*slot` |
| 6 | high byte secondary value из RAM `0x20004764 + 2*slot` |
| 7 | условный low/gate byte; firmware выбирает его по threshold/current state, это не всегда обычный low byte |
| 8 | low byte auxiliary word из RAM `0x20004A7C + 2*slot` |
| 9 | per-slot auxiliary byte из `0x20004B9C + slot` |
| 10 | per-key state byte из `0x200040EC + 8*slot + 4` |
| 11 | целая часть travel float |
| 12 | десятые доли |
| 13 | сотые доли |
| 14–15 | threshold, big-endian `u16`, выбранный по low 5 bits per-key config |
| 16–17 | auxiliary live word, big-endian, RAM `0x200043BC + 2*slot` |
| 18–19 | baseline/reference word, big-endian, RAM `0x20003EAC + 2*slot` |

Travel декодируется строго по инструкциям firmware:

```text
travel = byte11 + byte12 / 10 + byte13 / 100
```

Константа float `10.0` находится по VA `0xFD74`, file offset `0xAD74`. По смыслу значение почти наверняка выражено в миллиметрах, но единицу нужно подтвердить реальным пакетом при известном ходе клавиши.

## 7. Карта 68 клавиш

Scanner permutation:

- VA `0xFA94`
- file offset `0xAA94`
- 72 entries
- gaps: slots `8, 16, 35, 59`
- 68 уникальных internal IDs `0..67`

Descriptor table:

- VA `0xFB74`
- file offset `0xAB74`
- 72 тройки
- нулевые descriptors стоят в тех же четырёх gaps
- остальные 68 descriptors уникальны

Поэтому bytes `1..3` пакета однозначно преобразуются в scanner slot, internal ID и физическое имя клавиши. Полная таблица находится в `mad68pr_key_descriptor_map.csv`.

Физический порядок internal ID `0..67`:

```text
Esc 1 2 3 4 5 6 7 8 9 0 - = Backspace Insert
Tab Q W E R T Y U I O P [ ] Backslash Delete
CapsLock A S D F G H J K L Semicolon Apostrophe Enter PageUp
LeftShift Z X C V B N M Comma Period Slash RightShift Up PageDown
LeftCtrl LeftGUI LeftAlt Space RightAlt Fn RightCtrl Left Down Right
```

## 8. Что это даёт HallJoy

Для отдельного `MAD68ProR` backend правильная модель — stream transport:

1. открыть только vendor interface 1;
2. выполнить короткую state-split инициализацию `A9, A8, A9`;
3. постоянно читать endpoint `0x82`;
4. демультиплексировать `AA/AB` и `A0`;
5. по descriptor bytes `1..3` находить slot/key;
6. хранить dense snapshot 68 клавиш;
7. обновлять snapshot по `travel` и/или primary raw field;
8. на disconnect/reconnect повторять инициализацию;
9. на shutdown отправлять `A9`; полный latch сбросится после power-cycle.

Это не request/response polling по четыре клавиши, как старый Madlions backend, и не QBZ-подобная host-addressed команда. Это более выгодный firmware-driven change stream с тремя начальными full sweeps.

## 9. Артефакты

- `mad68pr_hidden_stream.py` — decoder, listener и явный `arm-listen` test.
- `mad68pr_command_map.csv` — все opcode `00..F2` и handler VA.
- `mad68pr_key_descriptor_map.csv` — slot/internal ID/key/descriptor.
- `mad68pr_threshold_table.csv` — 22 threshold constants.
- `mad68pr_stage2_manifest.json` — hashes, image base и table offsets.
- `snippet_*.txt` — релевантные фрагменты дизассемблирования.

## 10. Минимальный аппаратный тест

Установить Python package:

```powershell
py -m pip install hidapi
```

Проверить формирование команд без USB:

```powershell
py mad68pr_hidden_stream.py make-request 0xA8
py mad68pr_hidden_stream.py make-request 0xA9
```

Запустить state-split и чтение на 10 секунд:

```powershell
py mad68pr_hidden_stream.py arm-listen --duration 10 --jsonl mad68pr-hidden.jsonl
```

Для минимального промежутка между A8/A9:

```powershell
py mad68pr_hidden_stream.py arm-listen --arm-gap-ms 0 --duration 10
```

После уже выполненного arm можно подключаться read-only:

```powershell
py mad68pr_hidden_stream.py listen --duration 10
```

Ожидаемое поведение:

- сразу идут до 3 × 68 валидных reports (72 slots минус четыре gaps);
- буквенный ввод работает после немедленного A9;
- затем reports приходят при изменении хода конкретной клавиши;
- после unplug/replug поток прекращается до следующего arm.
