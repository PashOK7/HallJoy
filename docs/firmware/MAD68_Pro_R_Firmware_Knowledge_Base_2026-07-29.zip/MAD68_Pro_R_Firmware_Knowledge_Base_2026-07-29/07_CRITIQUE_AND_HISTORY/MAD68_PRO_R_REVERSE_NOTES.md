# MAD 68 Pro R firmware reverse — stage 1

## Inputs

- Firmware image: `35ed6b7a73cfe7e7fd222e6862032e49.bin`
- Size: `124656` bytes (`0x1E6F0`)
- SHA-256: `b8fd95a12402098caac3002741a4812ac9f51f51fad16b0d0752b966c5fe884c`
- HallJoy source archive SHA-256: `f34ba95d4120d5a1d62d57d5938a7381197e8d412792dcb7bbc9f55b03df4a05`

## Target identity

The USB device descriptor embedded at firmware offset `0xA8D4` contains:

- VID `0x373B`
- PID `0x1109`
- `bcdDevice 0x0102`
- Manufacturer: `Shenzhen Yizhita Technology Co., Ltd.`
- Product: `MAD 68 Pro R`
- String: `2024-04-25`

Build strings found in the image include `Apr 15 2025` and `14:30:20` / `14:30:22`.

## CPU and image layout

The executable code is little-endian RV32 for a WCH/QingKe-class MCU. Correct disassembly requires the standard RV32IMAC instruction set plus WCH XW compressed byte/halfword load-store instructions (`+xwchc`).

Reset code establishes approximately:

- `gp = 0x1FFFE2A0`
- `sp = 0x20003000`
- initialized-data source in flash at `0xC508`
- initialized-data destination at `0x1FFFB000`
- BSS start at `0x1FFFDAC0`

## USB layout

Configuration descriptor at firmware offset `0xC61C` has three interfaces:

1. Boot keyboard, IN endpoint `0x81`, 8-byte interrupt reports.
2. Vendor HID, IN endpoint `0x82`, OUT endpoint `0x04`, 64-byte reports.
3. Additional keyboard-like HID, IN endpoint `0x83`, 64-byte reports.

The interface-1 report descriptor at `0xA874` is unnumbered and defines one 64-byte input report and one 64-byte output report on Usage Page `0x0001`, Usage `0x0000`.

Windows HID buffers therefore normally have 65 bytes: an implicit leading report-ID byte `0x00`, followed by the 64 firmware-visible bytes below.

## Recovered vendor packet framing

Firmware parser: code at `0x1226`.

| Byte | Meaning |
|---:|---|
| `0` | Header: request `0x55`; normal response `0xAA`; checksum-error response `0xAB`; `0x5F` is an internal/raw path |
| `1` | Command/opcode |
| `2` | XOR key (`0` disables encryption) |
| `3` | 8-bit checksum |
| `4` | Data length, maximum `0x38` (56) |
| `5` | Offset/index low byte |
| `6` | Offset/index high byte |
| `7` | Extra parameter/subcommand/flags |
| `8..` | Data bytes |

### Request decode

1. Read XOR key from byte `2`.
2. When the key is nonzero, XOR-decrypt bytes `3` through `7 + data_length` with that key. Because byte `4` is itself encrypted, decrypt fixed metadata bytes `3..7` first, then decrypt the recovered data length.
3. Require header `0x55` and length `<= 0x38`.
4. Calculate checksum as the 8-bit sum of bytes `4 .. 7 + data_length` inclusive.
5. Compare it with byte `3`.

### Response encode

1. Set header to `0xAA` for a valid command response.
2. Recalculate byte `3` as the 8-bit sum of bytes `4 .. 7 + data_length`.
3. If byte `2` is nonzero, XOR bytes `3 .. 7 + data_length` with byte `2`.
4. Queue the 64-byte packet for the vendor IN endpoint.

An invalid checksum changes the response header to `0xAB` and places a checksum-error marker resembling `cserr` in the data area. An unknown command places an `unknw` marker in the data area.

## Independently confirmed command

A public MAD 68 Pro R RGB controller independently confirms this framing and identifies command `0x0B` as direct RGB-frame upload on a related hardware revision (`373B:10D4`, interface 1):

- request prefix `55 0B`;
- 384-byte RGB framebuffer;
- chunks of at most 56 bytes;
- LE16 framebuffer offset in bytes `5..6`;
- byte `7 = 1` on the first chunk and `0` afterward;
- byte `3` is the same 8-bit sum of bytes `4..63`;
- host writes report ID `0` plus the 64-byte payload.

This is strong external confirmation that the recovered parser is the active user protocol, not merely a dormant bootloader format. It does not identify the live Hall-travel opcode.

## Why the analog command is not yet statically identifiable

Command byte `1` indexes a 243-entry (`0x00..0xF2`) jump table at firmware address/file offset `0xF2C0`.

The supplied updater image is zero-filled at that address. The image has a broad zero-filled region beginning at `0xF000`; it also removes adjacent read-only data referenced by the code, including firmware version strings around `0xF68C` and `0xF699`.

Therefore:

- the common packet framing and individual command-handler behavior are recoverable;
- the mapping from command byte to handler is absent from this image;
- blindly probing all commands is unsafe because several handlers erase/write flash configuration and trigger state changes.

The missing mapping can be recovered from either:

1. a complete flash dump from a physical keyboard, especially the `0xF000..0xF7FF` area; or
2. one WebHID trace from the official web driver while its live key-travel view is active.

## Recovered read handlers

The parser contains handlers that copy data from these address regions into response byte `8` onward, using the LE16 offset in bytes `5..6` and requested size in byte `4`:

- `0x20DF0 + offset`
- `0x20000 + offset`
- `0x20CF0 + offset`
- `0x20BF0 + offset`
- `0x20800 + offset`
- `0x20400 + offset`
- `0x215F0 + offset`
- `0x20200 + offset`
- `0x225F0 + offset`
- `0x108A8 + offset`
- `0x20100 + 8-bit offset`
- `0x235F0 + 8-bit offset`

Corresponding write/erase handlers also exist, which is why opcode brute force should not be used.

## Scanner permutation

A 72-byte permutation table at firmware offset `0xAA94` contains all internal key IDs `0x00..0x43` plus four holes (`0xFF`), consistent with 68 physical keys in 72 scanner positions:

```text
10 12 15 0b 1d 30 35 3f ff 1f 21 23 18 1c 2f 34
ff 43 2d 13 24 19 2b 2e 26 37 39 01 04 07 0a 0e
31 3e 40 ff 2c 03 14 17 0d 3a 25 27 2a 00 02 05
08 0c 3c 33 36 41 1e 20 22 16 1a ff 32 28 38 0f
11 06 09 1b 3b 3d 29 42
```

This table should let the HallJoy backend translate scanner slots to the keyboard's internal key IDs after the live travel payload is identified.

## HallJoy implementation direction

MAD 68 Pro R must be a separate backend, not another PID under the existing MAD60/MAD68 `02 96 1C` protocol:

- enumerate VID/PID `373B:1109`;
- select the 64-byte bidirectional vendor HID interface (`0001:0000`), not the old `FF60:0061` interface;
- use 65-byte Windows buffers with report ID `0` and 64 bytes of protocol data;
- preserve HallJoy's existing overlapped-I/O cancellation and SafeHID lifetime model;
- first add passive packet decoding and replay tests;
- add the polling command only after it is captured or its jump-table entry is recovered.

## Included tools

- `madlions_webhid_trace.js`: passive DevTools/WebHID TX/RX logger for the official driver.
- `mad68pr_packet.py`: offline decoder for raw 64/65-byte packets and exported logger JSON. It never opens or writes to a HID device.
