# Происхождение материалов

Пакет собран из файлов, полученных и созданных в ходе анализа MADLIONS MAD 68 Pro R.

Основные первичные источники:

- firmware binary SHA-256 `2a7df4ffc491476b79da5333f51179f68fbbb5c5e146e987cfb5df764b79cead`;
- статический дизассемблированный образ с base `0x5000` и XWCHC decoding;
- аппаратный HallJoy log от устройства `VID 373B / PID 1109 / bcdDevice 0102`;
- diagnostic process logs;
- критический документ, предоставленный пользователем, и последующая raw-code проверка.

Файлы в `02_CURRENT_DOCUMENTATION` и корневой `00_README_MASTER_RU.md` имеют приоритет над историческими заметками.
